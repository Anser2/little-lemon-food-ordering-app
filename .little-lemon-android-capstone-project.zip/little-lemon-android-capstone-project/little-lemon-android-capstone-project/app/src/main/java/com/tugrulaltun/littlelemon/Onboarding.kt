package com.tugrulaltun.littlelemon

import android.annotation.SuppressLint
import android.content.Context
import android.widget.Toast
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.*
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CenterAlignedTopAppBar
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavHostController

@OptIn(ExperimentalMaterial3Api::class)
@SuppressLint("UnusedMaterial3ScaffoldPaddingParameter")
@Composable
fun Onboarding(navController: NavHostController) {

    val context = LocalContext.current

    var firstName by remember { mutableStateOf("") }
    var lastName by remember { mutableStateOf("") }
    var email by remember { mutableStateOf("") }

    Scaffold(
        topBar = {
            CenterAlignedTopAppBar(
                title = {
                    Image(
                        painter = painterResource(id = R.drawable.littlelemonimgtxt_nobg),
                        contentDescription = "Onboarding Top Bar Logo",
                        modifier = Modifier
                            .size(120.dp)

                    )
                },
                modifier = Modifier
                    .fillMaxWidth()
                    .background(Color.White),
            )
        },
        content = {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(top = 100.dp)
            ) {
                Box(
                    contentAlignment = Alignment.Center,
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(100.dp)
                        .background(Color(0xFF485E57))
                ) {
                    Text(
                        text = "Let's get to know you",
                        style = MaterialTheme.typography.bodyMedium,
                        textAlign = TextAlign.Center,
                        color = Color.White,
                        fontSize = 24.sp
                    )
                }

                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(start = 16.dp, end = 16.dp)
                ) {
                    Box(
                        contentAlignment = Alignment.CenterStart,
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(100.dp)
                    ) {
                        Text(
                            text = "Personal information",
                            fontWeight = FontWeight.Bold,
                            color = Color(0xFF1A1A35),
                        )
                    }

                    Text(
                        text = "First Name",
                        fontSize = 12.sp,
                        modifier = Modifier.padding(top = 16.dp, bottom = 6.dp),
                        color = Color(0xFF2f2f47),
                    )
                    BasicTextField(
                        value = firstName,
                        onValueChange = { firstName = it },
                        modifier = Modifier
                            .fillMaxWidth()
                            .border(
                                width = 1.dp,
                                color = Color(0xFFC8C9D2),
                                shape = RoundedCornerShape(5.dp)
                            )
                            .padding(start = 16.dp, top = 16.dp, bottom = 16.dp),
                    )

                    Text(
                        text = "Last Name",
                        fontSize = 12.sp,
                        modifier = Modifier.padding(top = 16.dp, bottom = 6.dp),
                        color = Color(0xFF2f2f47),
                    )
                    BasicTextField(
                        value = lastName,
                        onValueChange = { lastName = it },
                        modifier = Modifier
                            .fillMaxWidth()
                            .border(
                                width = 1.dp,
                                color = Color(0xFFC8C9D2),
                                shape = RoundedCornerShape(5.dp)
                            )
                            .padding(start = 16.dp, top = 16.dp, bottom = 16.dp),
                    )

                    Text(
                        text = "Email",
                        fontSize = 12.sp,
                        modifier = Modifier.padding(top = 16.dp, bottom = 6.dp),
                        color = Color(0xFF2f2f47),
                    )
                    BasicTextField(
                        value = email,
                        onValueChange = { email = it },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Email),
                        modifier = Modifier
                            .fillMaxWidth()
                            .border(
                                width = 1.dp,
                                color = Color(0xFFC8C9D2),
                                shape = RoundedCornerShape(5.dp)
                            )
                            .padding(start = 16.dp, top = 16.dp, bottom = 16.dp),
                    )
                }

                Box(
                    contentAlignment = Alignment.BottomCenter,
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(start = 16.dp, end = 16.dp)
                ) {
                    Button(
                        onClick = {
                            checkInputsAndNavigate(
                                firstName,
                                lastName,
                                email,
                                context,
                                navController
                            )
                        },
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 16.dp),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = Color(0xFFF4CE14),
                            contentColor = Color.Black,
                        ),
                        border = BorderStroke(
                            width = 1.dp,
                            color = Color(0xFFC57F22)
                        ),
                        shape = RoundedCornerShape(5.dp)
                    ) {
                        Text(
                            text = "Register"
                        )
                    }
                }
            }
        }
    )
}

private fun isValidEmail(email: String): Boolean {
    val emailPattern = "[a-zA-Z0-9._-]+@[a-z]+\\.+[a-z]+"
    return email.matches(emailPattern.toRegex())
}

private fun checkInputsAndNavigate(
    firstName: String,
    lastName: String,
    email: String,
    context: Context,
    navController: NavHostController
) {
    val firstNameStr = firstName.trim()
    val lastNameStr = lastName.trim()
    val emailStr = email.trim()

    if (firstName.isBlank() || lastName.isBlank() || email.isBlank()) {
        Toast.makeText(
            context,
            "Registration unsuccessful. Please enter all data.",
            Toast.LENGTH_SHORT
        ).show()
        return
    }

    if (!isValidEmail(email)) {
        Toast.makeText(
            context,
            "Invalid email format. Please enter a valid email address.",
            Toast.LENGTH_SHORT
        ).show()
        return
    }

    val sharedPreferences = context.getSharedPreferences(
        APP_SHARED_PREFS,
        Context.MODE_PRIVATE
    )
    val editor = sharedPreferences.edit()
    editor.putString(USER_FIRST_NAME, firstNameStr)
    editor.putString(USER_LAST_NAME, lastNameStr)
    editor.putString(USER_EMAIL, emailStr)
    editor.putBoolean(IS_LOGGED_IN, true)
    editor.apply()

    // Display success message and navigate to Home screen
    Toast.makeText(
        context,
        "Registration successful!",
        Toast.LENGTH_SHORT
    ).show()
    navController.navigate(Home.route)
}

@Preview
@Composable
fun OnboardingPreview() {
    Onboarding(navController = NavHostController(LocalContext.current))
}
