package com.tugrulaltun.littlelemon

import android.content.Context
import androidx.compose.runtime.Composable
import androidx.navigation.NavHostController
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable

fun isUserDataAvailable(context: Context): Boolean {
    val sharedPreferences = context.getSharedPreferences(APP_SHARED_PREFS, Context.MODE_PRIVATE)
    return sharedPreferences.contains(IS_LOGGED_IN)
}

@Composable
fun Navigation(navController: NavHostController, context: Context) {

    val startDestination = if (isUserDataAvailable(context)) {
        Home.route
    } else {
        Onboarding.route
    }

    NavHost(navController = navController, startDestination = startDestination) {
        composable(Onboarding.route) {
            Onboarding(navController)
        }
        composable(Home.route) {
            Home(navController)
        }
        composable(Profile.route) {
            Profile(navController)
        }
    }

}