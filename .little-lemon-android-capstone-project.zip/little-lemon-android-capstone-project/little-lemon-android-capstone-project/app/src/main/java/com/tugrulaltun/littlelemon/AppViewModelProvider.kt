package com.tugrulaltun.littlelemon

import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewmodel.CreationExtras
import androidx.lifecycle.viewmodel.initializer
import androidx.lifecycle.viewmodel.viewModelFactory

object AppViewModelProvider {
    val Factory = viewModelFactory {
        initializer {
            MenuViewModel(littleLemonApplication().container.itemsRepository)
        }
    }
}

fun CreationExtras.littleLemonApplication(): LittleLemonApplication =
    (this[ViewModelProvider.AndroidViewModelFactory.APPLICATION_KEY] as LittleLemonApplication)