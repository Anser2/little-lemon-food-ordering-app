package com.tugrulaltun.littlelemon

import android.app.Application

class LittleLemonApplication : Application() {

    lateinit var container: AppContainer

    override fun onCreate() {
        super.onCreate()
        DatabaseManager.initialize(this)
        container = AppDataContainer()
    }
}