package com.tugrulaltun.littlelemon

import kotlinx.coroutines.flow.Flow

interface ItemsRepository {
    fun getAllItemsStream(): Flow<List<MenuItemEntity>>
}