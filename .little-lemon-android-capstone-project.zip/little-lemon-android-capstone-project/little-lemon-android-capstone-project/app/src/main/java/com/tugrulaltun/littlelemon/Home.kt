package com.tugrulaltun.littlelemon

import android.annotation.SuppressLint
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.wrapContentSize
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AccountCircle
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Divider
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextField
import androidx.compose.material3.TextFieldDefaults
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavHostController
import com.bumptech.glide.integration.compose.ExperimentalGlideComposeApi
import com.bumptech.glide.integration.compose.GlideImage

@OptIn(ExperimentalMaterial3Api::class)
@SuppressLint("UnusedMaterial3ScaffoldPaddingParameter")
@Composable
fun Home(
    navController: NavHostController,
    viewModel: MenuViewModel = viewModel(factory = AppViewModelProvider.Factory)
) {
    val homeUiState by viewModel.homeUiState.collectAsState()
    var search by remember { mutableStateOf("") }
    var selectedCategory by remember { mutableStateOf("") }

    val categories = homeUiState.itemList.map { it.category }.distinct()

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Image(
                        painter = painterResource(id = R.drawable.littlelemonimgtxt_nobg),
                        contentDescription = "Home Top Bar Logo",
                        modifier = Modifier
                            .size(120.dp)

                    )
                },
                actions = {
                    IconButton(onClick = {
                        navController.navigate(Profile.route)
                    }) {
                        Icon(
                            imageVector = Icons.Default.AccountCircle,
                            contentDescription = "Profile Icon",
                            tint = Color(0xFF485E57)
                        )
                    }
                },
                modifier = Modifier
                    .fillMaxWidth()
                    .background(Color.White),
            )
        },
        content = {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(top = 80.dp)
            ) {
                HeroBanner(value = search, onValueSearchChange = { search = it })
                CategoryList(
                    categories,
                    selectedCategory,
                    onCategoryClick = { selectedCategory = it })
                MenuListArea(homeUiState.itemList, search, selectedCategory)
            }
        }
    )
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun HeroBanner(value: String, onValueSearchChange: (String) -> Unit = {}) {

    Column(
        verticalArrangement = Arrangement.Top,
        horizontalAlignment = Alignment.Start,
        modifier = Modifier
            .fillMaxWidth()
            .background(Color(0xFF495E57))
    ) {


        Text(
            text = stringResource(id = R.string.title),
            fontSize = 24.sp,
            color = Color(0xFFF4CE14),
            modifier = Modifier
                .padding(start = 20.dp, top = 20.dp)
                .height(50.dp)
                .clip(RoundedCornerShape(10.dp))
        )

        Text(
            text = stringResource(id = R.string.chicago),
            fontSize = 18.sp,
            color = Color(0xFFFFFFFF),
            modifier = Modifier.padding(start = 20.dp)
        )
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(20.dp),
            horizontalArrangement = Arrangement.Start,
        ) {
            Text(
                text = stringResource(id = R.string.description_one),
                modifier = Modifier.width(200.dp),
                color = Color.White,
                fontSize = 14.sp
            )
            Box(
                modifier = Modifier
                    .height(100.dp)
                    .clip(RoundedCornerShape(20.dp))
            ) {
                Image(
                    painter = painterResource(id = R.drawable.heroimage),
                    contentDescription = "Restaurant Image",
                    contentScale = ContentScale.Crop
                )
            }
        }

        Box(
            modifier = Modifier
                .padding(20.dp)
                .clip(RoundedCornerShape(10.dp))
                .background(Color(0xffeaeaea))
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(
                    imageVector = Icons.Default.Search,
                    contentDescription = "Search Icon",
                    tint = Color.Black,
                    modifier = Modifier.padding(8.dp)
                )

                TextField(
                    value = value,
                    onValueChange = onValueSearchChange,
                    placeholder = { Text("Enter search phrase") },
                    colors = TextFieldDefaults.textFieldColors(
                        containerColor = Color.Transparent,
                        focusedIndicatorColor = Color.Transparent,
                        unfocusedIndicatorColor = Color.Transparent,
                        cursorColor = Color.Gray
                    ),
                    modifier = Modifier
                        .fillMaxWidth()
                        .border(0.dp, Color.Transparent)
                )
            }
        }
    }
}

@OptIn(ExperimentalGlideComposeApi::class)
@Composable
fun MenuItem(menuItem: MenuItemEntity) {
    Card(
        colors = CardDefaults.cardColors(
            containerColor = Color.Transparent,
        )
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(8.dp)
        ) {
            Column {
                Text(
                    text = menuItem.title, fontSize = 18.sp, fontWeight = FontWeight.Bold
                )
                Text(
                    text = menuItem.description,
                    color = Color.Gray,
                    modifier = Modifier
                        .padding(top = 5.dp, bottom = 5.dp)
                        .fillMaxWidth(.75f)
                )
                Text(
                    text = "$" + menuItem.price, color = Color.Gray, fontWeight = FontWeight.Bold
                )
            }
            GlideImage(model = menuItem.image, contentDescription = "Menu Item Image")
        }
    }
    Divider(
        modifier = Modifier.padding(start = 8.dp, end = 8.dp),
        color = Color.LightGray,
        thickness = 1.dp
    )
}

@Composable
private fun MenuListArea(itemList: List<MenuItemEntity>, search: String, selectedCategory: String) {

    val filteredItemList = itemList.filter {
        (it.title.contains(search, ignoreCase = true) || it.description.contains(
            search,
            ignoreCase = true
        ))
                && (selectedCategory.isEmpty() || it.category == selectedCategory)
    }

    Column {
        Divider(
            modifier = Modifier.padding(start = 8.dp, end = 8.dp),
            color = Color.LightGray,
            thickness = 1.dp
        )
        MenuList(filteredItemList)
    }
}

@Composable
fun CategoryCard(name: String, isSelected: Boolean, onClick: () -> Unit = {}) {
    Card(
        colors = CardDefaults.cardColors(
            containerColor = if (isSelected) Color(0xFFd8d8d8) else Color(0xFFedefee),
        ),
        modifier = Modifier
            .padding(end = 8.dp)
            .wrapContentSize()
            .clickable { onClick() }
    ) {
        Text(
            text = name.replaceFirstChar { it.uppercase() },
            fontSize = 16.sp,
            fontWeight = FontWeight.Bold,
            modifier = Modifier
                .padding(8.dp)
                .background(Color.Transparent),
            color = Color(0xFF3d544c)
        )
    }
}

@Composable
fun CategoryList(
    categories: List<String>,
    selectedCategory: String,
    onCategoryClick: (String) -> Unit
) {
    Text(
        text = "ORDER FOR DELIVERY!",
        fontSize = 16.sp,
        fontWeight = FontWeight.Bold,
        modifier = Modifier.padding(start = 16.dp, top = 8.dp, bottom = 8.dp)
    )

    LazyRow(
        modifier = Modifier
            .padding(start = 16.dp, top = 8.dp, bottom = 8.dp)
    ) {
        items(categories) { category ->
            CategoryCard(
                name = category,
                isSelected = category == selectedCategory,
                onClick = {
                    if (category == selectedCategory) {
                        onCategoryClick("")
                    } else {
                        onCategoryClick(category)
                    }
                }
            )
        }
    }
}

@Composable
fun MenuList(itemList: List<MenuItemEntity>) {
    LazyColumn(
        modifier = Modifier
            .padding(start = 8.dp, top = 8.dp, bottom = 8.dp)
    ) {
        items(itemList) { menuItemEntity ->
            MenuItem(menuItemEntity)
        }
    }
}

@Composable
@Preview
fun HomePreview() {
    Home(navController = NavHostController(LocalContext.current))
}