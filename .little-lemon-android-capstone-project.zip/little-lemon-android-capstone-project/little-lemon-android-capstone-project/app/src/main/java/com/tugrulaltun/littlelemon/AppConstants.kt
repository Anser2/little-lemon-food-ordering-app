package com.tugrulaltun.littlelemon

const val APP_SHARED_PREFS = "LittleLemonPrefs"

const val IS_LOGGED_IN = "IS_LOGGED_IN"

const val USER_FIRST_NAME = "USER_FIRST_NAME"
const val USER_LAST_NAME = "USER_LAST_NAME"
const val USER_EMAIL = "USER_EMAIL"

const val APP_DATABASE_NAME = "APP_DATABASE_NAME"