package com.tugrulaltun.littlelemon

import kotlinx.coroutines.flow.Flow

class OfflineItemsRepository(private val itemDao: MenuItemDao) : ItemsRepository {
    override fun getAllItemsStream(): Flow<List<MenuItemEntity>> = itemDao.getAllMenuItems()
}