package com.tugrulaltun.littlelemon

interface AppContainer {
    val itemsRepository: ItemsRepository
}

class AppDataContainer : AppContainer {
    override val itemsRepository: ItemsRepository by lazy {
        OfflineItemsRepository(DatabaseManager.getMenuItemDao())
    }
}