package com.tugrulaltun.littlelemon

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.runtime.Composable
import androidx.compose.ui.platform.LocalContext
import androidx.lifecycle.lifecycleScope
import androidx.navigation.compose.rememberNavController
import com.tugrulaltun.littlelemon.ui.theme.LittleLemonTheme
import io.ktor.client.HttpClient
import io.ktor.client.call.body
import io.ktor.client.plugins.contentnegotiation.ContentNegotiation
import io.ktor.client.request.get
import io.ktor.http.ContentType
import io.ktor.serialization.kotlinx.json.json
import kotlinx.coroutines.launch

class MainActivity : ComponentActivity() {

    private val client = HttpClient() {
        install(ContentNegotiation) {
            json(contentType = ContentType("text", "plain"))
        }
    }

    private suspend fun getMenu(): List<MenuItemNetworkData> {
        val response: MenuNetworkData = client
            .get(
                "https://raw.githubusercontent.com/Meta-Mobile-Developer-PC/Working-With-Data-API/main/menu.json",
            )
            .body()
        return response.menu
    }

    private suspend fun saveMenuItemToDatabase(menuItemData: MenuItemNetworkData) {
        val menuItemEntity = menuItemData.toMenuItemEntity()
        DatabaseManager.getMenuItemDao().insertMenuItem(menuItemEntity)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        lifecycleScope.launch {
            val menuItems = getMenu()
            menuItems.forEach { menuItem ->
                saveMenuItemToDatabase(menuItem)
            }
        }

        setContent {
            LittleLemonTheme {
                MyNavigation()
            }
        }
    }
}

@Composable
fun MyNavigation() {
    val context = LocalContext.current
    val navController = rememberNavController()
    Navigation(navController = navController, context = context)
}