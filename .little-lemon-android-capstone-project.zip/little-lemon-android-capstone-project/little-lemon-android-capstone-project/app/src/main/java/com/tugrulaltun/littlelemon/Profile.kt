package com.tugrulaltun.littlelemon

import android.annotation.SuppressLint
import android.content.Context
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CenterAlignedTopAppBar
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavHostController

@OptIn(ExperimentalMaterial3Api::class)
@SuppressLint("UnusedMaterial3ScaffoldPaddingParameter")
@Composable
fun Profile(navController: NavHostController) {
    val context = LocalContext.current
    val sharedPreferences = context.getSharedPreferences(APP_SHARED_PREFS, Context.MODE_PRIVATE)

    var firstName = sharedPreferences.getString(USER_FIRST_NAME, "") ?: ""
    var lastName = sharedPreferences.getString(USER_LAST_NAME, "") ?: ""
    var email = sharedPreferences.getString(USER_EMAIL, "") ?: ""

    Scaffold(
        topBar = {
            CenterAlignedTopAppBar(
                title = {
                    Image(
                        painter = painterResource(id = R.drawable.littlelemonimgtxt_nobg),
                        contentDescription = "Profile Top Bar Logo",
                        modifier = Modifier
                            .size(120.dp)

                    )
                },
                modifier = Modifier
                    .fillMaxWidth()
                    .background(Color.White),
            )
        },
        content = {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(top = 150.dp)
            ) {

                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(start = 16.dp, end = 16.dp)
                ) {
                    Box(
                        contentAlignment = Alignment.CenterStart,
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(100.dp)
                    ) {
                        Text(
                            text = "Personal information",
                            fontWeight = FontWeight.Bold,
                            color = Color(0xFF1A1A35),
                        )
                    }

                    Text(
                        text = "First Name",
                        fontSize = 12.sp,
                        modifier = Modifier.padding(top = 16.dp, bottom = 6.dp),
                        color = Color(0xFF2f2f47),
                    )
                    Text(
                        text = firstName,
                        modifier = Modifier
                            .fillMaxWidth()
                            .border(
                                width = 1.dp,
                                color = Color(0xFFC8C9D2),
                                shape = RoundedCornerShape(5.dp)
                            )
                            .padding(start = 16.dp, top = 16.dp, bottom = 16.dp),
                    )

                    Text(
                        text = "Last Name",
                        fontSize = 12.sp,
                        modifier = Modifier.padding(top = 16.dp, bottom = 6.dp),
                        color = Color(0xFF2f2f47),
                    )
                    Text(
                        text = lastName,
                        modifier = Modifier
                            .fillMaxWidth()
                            .border(
                                width = 1.dp,
                                color = Color(0xFFC8C9D2),
                                shape = RoundedCornerShape(5.dp)
                            )
                            .padding(start = 16.dp, top = 16.dp, bottom = 16.dp),
                    )

                    Text(
                        text = "Email",
                        fontSize = 12.sp,
                        modifier = Modifier.padding(top = 16.dp, bottom = 6.dp),
                        color = Color(0xFF2f2f47),
                    )
                    Text(
                        text = email,
                        modifier = Modifier
                            .fillMaxWidth()
                            .border(
                                width = 1.dp,
                                color = Color(0xFFC8C9D2),
                                shape = RoundedCornerShape(5.dp)
                            )
                            .padding(start = 16.dp, top = 16.dp, bottom = 16.dp),
                    )
                }

                Box(
                    contentAlignment = Alignment.BottomCenter,
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(start = 16.dp, end = 16.dp)
                ) {
                    Button(
                        onClick = {
                            sharedPreferences.edit().clear().apply()
                            navController.navigate(Onboarding.route)
                        },
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 16.dp),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = Color(0xFFF4CE14),
                            contentColor = Color.Black,
                        ),
                        border = BorderStroke(
                            width = 1.dp,
                            color = Color(0xFFC57F22)
                        ),
                        shape = RoundedCornerShape(5.dp)
                    ) {
                        Text(
                            text = "Log out"
                        )
                    }
                }
            }
        }
    )
}

@Composable
@Preview
fun ProfilePreview() {
    Profile(navController = NavHostController(LocalContext.current))
}