package com.tugrulaltun.littlelemon

import kotlinx.serialization.SerialName
import kotlinx.serialization.Serializable

@Serializable
class MenuNetworkData {
    @SerialName("menu")
    var menu: List<MenuItemNetworkData> = emptyList()
}

@Serializable
data class MenuItemNetworkData(
    val id: String,
    val title: String,
    val description: String,
    val price: String,
    val image: String,
    val category: String
)

fun MenuItemNetworkData.toMenuItemEntity(): MenuItemEntity {
    return MenuItemEntity(id, title, description, price, image, category)
}